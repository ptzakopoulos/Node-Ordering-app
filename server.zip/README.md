# Node-Ordering-app

Food Delivery App with Node Js

## Tasks to be done

- [x] Login Validation
- [x] Password encryption
- [x] Email provider
- [ ] Temporary cart
- [ ] User Password Reset - Feature
- [x] Adjust Scemas refs and objects
- [x] Session Management

:file_folder: Folder

<h1 style="color : red;"> hello </h1>
<progressive-image>
<img src="./public/images/404.jpg">
</progressive-image>
